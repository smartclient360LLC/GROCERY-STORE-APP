# 🔧 Fix: Local Services Not Starting

## Issues Fixed

### 1. ✅ Payment Service - Missing Stripe Keys
**Error:** `Could not resolve placeholder 'STRIPE_SECRET_KEY'`

**Fix Applied:**
- Added placeholder defaults in `application.yml`
- Service will start with placeholder keys (won't process real payments)

**To use real Stripe keys:**
```bash
export STRIPE_SECRET_KEY=sk_test_your_key_here
export STRIPE_PUBLIC_KEY=pk_test_your_key_here
cd backend/payment-service && ./run.sh
```

### 2. ✅ Order Service - Port Conflict
**Issue:** Port was set to 8082 (conflicts with catalog-service)

**Fix Applied:**
- Changed order-service port to **8085**
- Updated catalog service URL reference to port 8084

## Correct Service Ports

| Service | Port | Status |
|---------|------|--------|
| auth-service | 8081 | ✅ |
| catalog-service | 8082 | ✅ |
| cart-service | 8083 | ✅ |
| order-service | **8085** | ✅ Fixed |
| payment-service | 8086 | ✅ Fixed |
| api-gateway | 8087 | ✅ |

## Starting Services Locally

### Option 1: Stop Docker First (Recommended)

```bash
# Stop Docker containers
./stop-docker-services.sh

# Or stop everything
docker-compose down
```

### Option 2: Start Services in Separate Terminals

```bash
# Terminal 1 - Auth Service
cd backend/auth-service && ./run.sh

# Terminal 2 - Catalog Service
cd backend/catalog-service && ./run.sh

# Terminal 3 - Cart Service
cd backend/cart-service && ./run.sh

# Terminal 4 - Order Service (now port 8085)
cd backend/order-service && ./run.sh

# Terminal 5 - Payment Service (with Stripe keys)
export STRIPE_SECRET_KEY=sk_test_your_key
export STRIPE_PUBLIC_KEY=pk_test_your_key
cd backend/payment-service && ./run.sh

# Terminal 6 - API Gateway
cd backend/api-gateway && ./run.sh
```

## Setting Stripe Keys

### For Local Development

1. **Get your Stripe test keys** from https://dashboard.stripe.com/test/apikeys

2. **Set environment variables:**
   ```bash
   export STRIPE_SECRET_KEY=sk_test_...
   export STRIPE_PUBLIC_KEY=pk_test_...
   ```

3. **Or create a `.env` file** in `backend/payment-service/`:
   ```bash
   STRIPE_SECRET_KEY=sk_test_...
   STRIPE_PUBLIC_KEY=pk_test_...
   ```

4. **Then run:**
   ```bash
   cd backend/payment-service
   source .env  # if using .env file
   ./run.sh
   ```

## Testing Without Stripe Keys

The payment service will start with placeholder keys, but:
- ⚠️ Payment processing will fail
- ✅ Other services will work fine
- ✅ You can test the rest of the application

## Troubleshooting

### Port Already in Use
```bash
# Check what's using the port
lsof -i :8085

# Kill the process or stop Docker containers
docker stop payment-service
```

### Database Connection Issues
Make sure PostgreSQL is running:
```bash
# If using Docker
docker ps | grep postgres

# Or start local PostgreSQL
brew services start postgresql@15
```

### RabbitMQ Connection Issues
Make sure RabbitMQ is running:
```bash
# If using Docker
docker ps | grep rabbitmq

# Or start local RabbitMQ
brew services start rabbitmq
```

---

**All services should now start successfully!** 🎉
