# 🔧 Fix: Local Services Not Starting

## Problem
Local services can't start because Docker containers are using the same ports.

## Current Situation

**Docker containers running:**
- auth-service: Port 8081 ✅
- catalog-service: Port 8082 ✅
- cart-service: Port 8083 ✅
- order-service: Port 8084 ✅ (Docker)
- payment-service: Port 8085 ✅ (Docker)
- api-gateway: Port 8080 ✅

**Port conflict:**
- order-service `application.yml` is configured for port **8085**
- But Docker `payment-service` is using port **8085**
- Docker `order-service` is using port **8084**

## Solutions

### Option 1: Stop Docker Containers (Recommended for Local Development)

If you want to run services locally (not in Docker):

```bash
# Stop all Docker containers
docker-compose down

# Or stop specific services
docker stop payment-service order-service auth-service catalog-service cart-service api-gateway

# Then start services locally using run.sh scripts
cd backend/auth-service && ./run.sh
cd backend/catalog-service && ./run.sh
# etc.
```

### Option 2: Fix Port Mismatch in order-service

The `order-service` has a port mismatch:
- `application.yml` says port **8085**
- But it should be **8084** (as per docker-compose)

**Fix order-service port:**

```yaml
# backend/order-service/src/main/resources/application.yml
server:
  port: 8084  # Change from 8085 to 8084
```

### Option 3: Use Different Ports for Local Development

Create a local `application-local.yml` for development:

```yaml
# backend/order-service/src/main/resources/application-local.yml
server:
  port: 8088  # Use a different port for local dev
```

Then run with:
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

## Quick Fix: Stop Docker and Start Locally

```bash
# 1. Stop Docker containers
docker-compose down

# 2. Start services locally (in separate terminals)
cd backend/auth-service && ./run.sh
cd backend/catalog-service && ./run.sh
cd backend/cart-service && ./run.sh
cd backend/order-service && ./run.sh
cd backend/payment-service && ./run.sh
cd backend/api-gateway && ./run.sh
```

## Service Ports (Correct)

| Service | Port | Docker Port | Local Port |
|---------|------|-------------|------------|
| auth-service | 8081 | 8081 | 8081 |
| catalog-service | 8082 | 8082 | 8082 |
| cart-service | 8083 | 8083 | 8083 |
| order-service | **8084** | 8084 | **8085** (needs fix) |
| payment-service | 8086 | 8085 | 8086 |
| api-gateway | 8087 | 8080 | 8087 |

## Recommended Action

**Fix the order-service port mismatch first:**

1. Update `backend/order-service/src/main/resources/application.yml`:
   ```yaml
   server:
     port: 8084  # Change from 8085
   ```

2. Then either:
   - Stop Docker: `docker-compose down`
   - Or use different ports for local dev
