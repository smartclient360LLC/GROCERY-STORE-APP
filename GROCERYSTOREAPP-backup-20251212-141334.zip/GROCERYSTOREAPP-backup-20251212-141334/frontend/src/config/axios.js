// Re-export apiClient from api.js for backward compatibility
export { default } from './api'

