package com.grocerystore.order.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FrequentlyOrderedProductDto {
    private Long productId;
    private String productName;
    private BigDecimal averagePrice;
    private Integer totalTimesOrdered;
    private Integer averageQuantity;
    private BigDecimal averageWeight; // For weight-based items
    private String lastOrderedDate;
}

