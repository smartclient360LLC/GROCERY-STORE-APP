# 🔧 Fix: Services Not Starting

## Problem
All services except API Gateway were failing to start with "tasks failed to start" errors.

## Root Cause
The `RABBITMQ_HOST` environment variable was incorrectly set with the protocol and port:
- ❌ **Wrong:** `amqps://b-bede77dc-0652-44cb-b9ff-580e384de00b.mq.us-east-2.on.aws:5671`
- ✅ **Correct:** `b-bede77dc-0652-44cb-b9ff-580e384de00b.mq.us-east-2.on.aws`

## Solution Applied

1. **Fixed Task Definitions:**
   - Updated all 5 service task definitions (auth, catalog, cart, order, payment)
   - Corrected `RABBITMQ_HOST` to just the hostname
   - Set `RABBITMQ_PORT` to `5671` (SSL port)
   - Verified `RABBITMQ_USER` and `RABBITMQ_PASSWORD` are correct

2. **Updated Services:**
   - Updated all services to use the latest task definition revisions
   - Forced new deployments

## Current Status

All services are now deploying with corrected environment variables:
- ✅ auth-service: Task definition revision 4
- ✅ catalog-service: Task definition revision 3
- ✅ cart-service: Task definition revision 3
- ✅ order-service: Task definition revision 3
- ✅ payment-service: Task definition revision 4

## Next Steps

1. **Wait 1-2 minutes** for tasks to start
2. **Check service status:**
   ```bash
   aws ecs describe-services \
       --cluster grocerystore-cluster \
       --services $(aws ecs list-services --cluster grocerystore-cluster --region us-east-2 --query 'serviceArns' --output text | tr '\t' ' ') \
       --region us-east-2 \
       --query 'services[*].{Name:serviceName,Running:runningCount,Desired:desiredCount}' \
       --output table
   ```

3. **If services still fail:**
   - Check CloudWatch logs: `/ecs/grocerystore-{service}`
   - Verify RabbitMQ SSL configuration (see below)

## Potential Issue: RabbitMQ SSL

If services still fail to connect to RabbitMQ, you may need to:

### Option 1: Use Non-SSL Port (Simpler)
Check if AWS MQ has a non-SSL endpoint on port 5672:
1. Go to AWS MQ Console
2. Check "Endpoints" tab
3. If port 5672 is available, update task definitions to use port 5672

### Option 2: Enable SSL in Spring Boot (If needed)
If port 5672 is not available, you may need to add SSL configuration to Spring Boot applications. However, Spring Boot should automatically handle SSL for port 5671.

## Environment Variables (Corrected)

All services now have:
```
RABBITMQ_HOST=b-bede77dc-0652-44cb-b9ff-580e384de00b.mq.us-east-2.on.aws
RABBITMQ_PORT=5671
RABBITMQ_USER=admin
RABBITMQ_PASSWORD=Smartclient360LLC
```

## Monitoring

Check logs if services don't start:
```bash
# Check logs for a specific service
aws logs tail /ecs/grocerystore-auth-service --follow --region us-east-2

# Check all services
for service in auth-service catalog-service cart-service order-service payment-service; do
    echo "=== $service ==="
    aws logs tail /ecs/grocerystore-$service --since 10m --region us-east-2 | tail -20
    echo ""
done
```

---

**Status:** Fixed and deploying. Monitor services in ECS console.
